#!/usr/bin/env python3
"""TODO: Completar el contador de k-mers.

Requerimientos:
- Validar que la secuencia solo tenga A,T,C,G.
- Leer k desde una opción -k / --kmer_size.
- Imprimir k-mers y conteos.
"""
import argparse

def validate_sequence(seq):
    """TODO: Validar la secuencia."""
    pass

def count_kmers(seq, k):
    """TODO: Implementar el conteo de k-mers."""
    pass

def main():
    # TODO: construir el parser, leer args y llamar a las funciones.
    pass

if __name__ == "__main__":
    main()
